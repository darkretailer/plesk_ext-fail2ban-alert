# 1.0.0 (26 November 2021)

* [+] Initial release.